package com.yash.damsapp.daoimpl;

import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.yash.damsapp.dao.UserDAO;
import com.yash.damsapp.domain.Schedule;
import com.yash.damsapp.domain.User;

@Repository
public class UserDAOImpl implements UserDAO {
	@Autowired
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	public DataSource getDataSource() {
		return dataSource;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public boolean insert(User user) {
		String sql = "insert into users(first_name,last_name,contact,address,email,loginname,password) values(?,?,?,?,?,?,?)";
		Object[] params = new Object[] { user.getFirst_name(), user.getLast_name(), user.getContact(),
				user.getAddress(), user.getEmail(), user.getLoginname(), user.getPassword() };
		try {
			jdbcTemplate.update(sql, params);
			return true;
		} catch (DataIntegrityViolationException ex) {
			return false;
		}
	}

	public void scheduleapp(Schedule schedule) {
		String sql = "insert into schedule(userid,date,start_time) values(?,?,?)";
		String stime = schedule.getStarttime();
		String etime = schedule.getEndtime();
		SimpleDateFormat format = new SimpleDateFormat("HH:mm");
		long difference = 0;
		try {
			Date date1 = format.parse(stime);
			Date date2 = format.parse(etime);
			difference = date2.getTime() - date1.getTime();
			System.out.println(difference);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String[] stimeparts = stime.split(":");
		Time timestart = new Time(Integer.parseInt(stimeparts[0]), Integer.parseInt(stimeparts[1]), 00);
		int times = (int) (difference / 900000);
		System.out.println(times);
		int i = 0;
		while (i < times) {
			Object[] params = new Object[] { schedule.getUserid(), schedule.getDateofapp(), timestart.toString() };
			jdbcTemplate.update(sql, params);
			timestart.setMinutes(timestart.getMinutes() + 15);
			i++;
			System.out.println(timestart.toString());
		}
	}

}
