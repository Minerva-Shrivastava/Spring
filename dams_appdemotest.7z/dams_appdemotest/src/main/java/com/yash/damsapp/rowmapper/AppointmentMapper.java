package com.yash.damsapp.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.yash.damsapp.domain.Appointment;

public class AppointmentMapper implements RowMapper<Appointment> {

	public Appointment mapRow(ResultSet rs, int arg1) throws SQLException {
		Appointment appointment=new Appointment();
		appointment.setId(rs.getInt("id"));
		appointment.setDate_created(rs.getDate("date_created"));
		appointment.setStart_time(rs.getTime("start_time"));
		appointment.setEnd_time(rs.getTime("end_time"));
		appointment.setEnd_time_expected(rs.getTime("end_time_expected"));
		appointment.setSlot(rs.getInt("slot"));
		appointment.setCancel(rs.getInt("cancel"));
		appointment.setFee(rs.getInt("fee"));
		appointment.setDiscount(rs.getInt("discount"));
		return appointment;
	}

	
}
