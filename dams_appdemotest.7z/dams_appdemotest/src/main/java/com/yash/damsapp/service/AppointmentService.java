package com.yash.damsapp.service;

import java.util.Date;
import java.util.List;

import com.yash.damsapp.domain.Appointment;
import com.yash.damsapp.domain.Schedule;

public interface AppointmentService {

	public List<Schedule> getAppointments(String doapp );

	public void bookAppointment(Appointment appointment);

	public List<Appointment> listappoint();

	public void cancelAppointment(Integer id);

	public void deleteAppointment(Integer id);
}
