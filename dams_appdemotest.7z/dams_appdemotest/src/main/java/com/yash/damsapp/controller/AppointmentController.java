package com.yash.damsapp.controller;

import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.yash.damsapp.domain.Appointment;
import com.yash.damsapp.domain.Schedule;
import com.yash.damsapp.domain.User;
import com.yash.damsapp.service.AppointmentService;

@Controller
@RequestMapping("/patient")
public class AppointmentController {
	@Autowired
	AppointmentService appointmentService;

	@RequestMapping(value = "/patientDashboard.htm", method = RequestMethod.GET)
	public String showPatientDashboard() {
		return "patientDashboard";
	}

	@RequestMapping(value = "/logout.htm", method = RequestMethod.GET)
	public String logout() {
		return "userLogin";
	}

	@RequestMapping(value = "/listAppointments.htm", method = RequestMethod.GET)
	public String showAppointments( Model model) {
		List<Appointment> appointments= appointmentService.listappoint();
		model.addAttribute("appointments",appointments);
		return "listAppointment";
	}

	@RequestMapping(value = "/getAppointments.htm", method = RequestMethod.POST)
	public String getAppointments(@RequestParam String doapp, Model model) {
		List<Schedule> appointments = appointmentService.getAppointments(doapp);

		System.out.println(doapp.toString());
		for (Schedule schedule : appointments) {
			System.out.println(schedule.getDateofapp().toString() + "" + schedule.getUserid());
		}
		model.addAttribute("appointments", appointments);
		model.addAttribute("dateofapp", (doapp));
		return "patientDashboard";
	}

	@RequestMapping(value = "/bookAppointments.htm", method = RequestMethod.POST)
	public String bookAppointment(@RequestParam String doapp,
			@RequestParam String start_time) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dateparsed = null;
		try {
			dateparsed = sdf.parse(doapp);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String[] stimeparts = start_time.split(":");
		Time timestart=new Time(Integer.parseInt(stimeparts[0]),Integer.parseInt(stimeparts[1]),00);
		Appointment appointment = new Appointment();
		appointment.setId(9);
		appointment.setDate_created(dateparsed);
		appointment.setStart_time(timestart);
		Time timeend=new Time(timestart.getHours(),timestart.getMinutes()+15,timestart.getSeconds());
		appointment.setEnd_time_expected(timeend);
		appointmentService.bookAppointment(appointment);
		return "patientDashboard";
	}

	@RequestMapping(value = "/cancelAppointment.htm", method = RequestMethod.GET)
	public String cancelAppointment(@RequestParam Integer id) {
		System.out.println("appointment to be cancelled : "+id);
		appointmentService.cancelAppointment(id);
		return "redirect:./listAppointments.htm";
	}

	@RequestMapping(value = "/deleteAppointment.htm", method = RequestMethod.GET)
	public String deleteAppointment(@RequestParam Integer id) {
		System.out.println("appointment to be deleted : "+id);
		appointmentService.deleteAppointment(id);
		return "redirect:./listAppointments.htm";
	}

}
