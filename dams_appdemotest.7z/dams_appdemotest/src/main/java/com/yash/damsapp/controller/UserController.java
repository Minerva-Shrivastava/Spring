package com.yash.damsapp.controller;

import java.sql.Timestamp;
import java.util.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.yash.damsapp.domain.Schedule;
import com.yash.damsapp.domain.User;
import com.yash.damsapp.service.UserService;

@Controller
@RequestMapping("/user")
@SessionAttributes("userinsession")
public class UserController {
	@Autowired
	UserService userService;

	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public String showHelloWorld() {
		return "home";
	}

	@RequestMapping(value = "/userRegister.htm", method = RequestMethod.GET)
	public String showRegistrationForm() {
		return "userRegistration";
	}

	@RequestMapping(value = "/processUserRegistration.htm", method = RequestMethod.POST)
	public String register(@ModelAttribute("user") User user, Model model) {
		boolean userStatus=userService.userRegister(user);
		if(userStatus){
		return "redirect:./hello.htm";
	}else{
		Boolean alert=true;
		model.addAttribute("alert",alert);
		return "userRegistration";
	}
		}

	@RequestMapping(value = "/userLogin.htm", method = RequestMethod.GET)
	public String loginForm() {
		return "userLogin";
	}

	@RequestMapping(value = "/login.htm", method = RequestMethod.POST)
	public String userLogin(@RequestParam String loginname, @RequestParam String password, @RequestParam String email,Model model) {
		User checkuser = userService.checkUserLogin(loginname, password, email);
		if (checkuser != null) {
				model.addAttribute("userinsession", checkuser);
				if(checkuser.getRole()==2){
					return "userDashboard";
				}
				else{
					return "redirect:../patient/patientDashboard.htm";
				}
		} else {
			model.addAttribute("err", "invalid user credentials");
			return "userLogin";
		}
	}
	
	@RequestMapping(value = "/logout.htm", method = RequestMethod.GET)
	public String logout(HttpSession session,Model model) {
		model.addAttribute("userinsession", new User());
		
		session.invalidate();
		return "userLogin";
	}


	@RequestMapping(value = "/scheduleapp.htm", method = RequestMethod.GET)
	public String scheduleAppointment(@RequestParam Integer userid,@RequestParam Date dateofapp,@RequestParam String endtime,@RequestParam String starttime ) { 
		Schedule schedule=new Schedule();
		schedule.setUserid(userid);
		schedule.setDateofapp(dateofapp);
		schedule.setEndtime(endtime);
		schedule.setStarttime(starttime);
		userService.scheduleApp(schedule);
		return "home";
	}


}