package com.yash.userapp.controller;

import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.yash.userapp.model.User;

public class UserController implements Controller{

	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {

		User user = new User();
		user.setName(request.getParameter("name"));
		user.setContact	(request.getParameter("contact"));
		user.setEmail(request.getParameter("email"));
		user.setAddress(request.getParameter("address"));
		
		Map<String, User> userMap = new HashMap<>();
		userMap.put("user", user);
		
		return new ModelAndView("welcome",userMap);
	}

	
}
