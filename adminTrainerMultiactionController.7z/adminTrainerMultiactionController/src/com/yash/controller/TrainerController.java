package com.yash.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/trainer")
public class TrainerController {
	@RequestMapping(value="/trainer.ds")
	public String toWelcomeTrainer() {
		return "welcomeTrainer";
	}
	
	@RequestMapping(value="/add.ds", method=RequestMethod.GET)
	public ModelAndView addTrainer() {
		Map<String, String> addCourseMap=new HashMap<>();
		addCourseMap.put("msg", "course added");
		return new ModelAndView("welcome", addCourseMap);
	}
	
	@RequestMapping(value="/update.ds", method=RequestMethod.GET)
	public ModelAndView updateTrainer() {
		Map<String, String> updateCourserMap=new HashMap<>();
		updateCourserMap.put("msg", "Course updated");
		return new ModelAndView("welcome", updateCourserMap);
	}
	
	@RequestMapping(value="/view.ds", method=RequestMethod.GET)
	public ModelAndView viewCourse() {
		Map<String, String> viewCourserMap=new HashMap<>();
		viewCourserMap.put("msg", "view courses");
		return new ModelAndView("welcome", viewCourserMap);
	}
	
	@RequestMapping("/delete.ds")
	public ModelAndView deleteTrainer() {
		Map<String, String> deleteCourseMap=new HashMap<>();
		deleteCourseMap.put("msg", "Course deleted");
		return new ModelAndView("welcome", deleteCourseMap);
	}
	
	
}
