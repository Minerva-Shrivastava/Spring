package com.yash.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;



@Controller
@RequestMapping("/admin")
public class AdminController {

	@RequestMapping("/admin.ds")
	public String toWelcomeAdmin() {
		return "welcomeAdmin";
	}
	@RequestMapping(value="/add.ds", method=RequestMethod.GET)
	public ModelAndView addTrainer() {
		Map<String, String> addTrainerMap=new HashMap<>();
		addTrainerMap.put("msg", "Trainer added");
		return new ModelAndView("welcome", addTrainerMap);
	}
	
	@RequestMapping(value="/update.ds", method=RequestMethod.GET)
	public ModelAndView updateTrainer() {
		Map<String, String> updateTrainerMap=new HashMap<>();
		updateTrainerMap.put("msg", "Trainer updated");
		return new ModelAndView("welcome", updateTrainerMap);
	}
	
	@RequestMapping(value="/view.ds", method=RequestMethod.GET)
	public ModelAndView viewTrainer() {
		Map<String, String> viewTrainerMap=new HashMap<>();
		viewTrainerMap.put("msg", "view trainers");
		return new ModelAndView("welcome", viewTrainerMap);
	}
	
	@RequestMapping(value="/delete.ds", method=RequestMethod.GET)
	public ModelAndView deleteTrainer() {
		Map<String, String> deleteTrainerMap=new HashMap<>();
		deleteTrainerMap.put("msg", "Trainer deleted");
		return new ModelAndView("welcome", deleteTrainerMap);
	}
	
	
}
