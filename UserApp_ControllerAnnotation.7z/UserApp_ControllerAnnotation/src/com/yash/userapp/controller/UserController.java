package com.yash.userapp.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
@RequestMapping("/Users")
public class UserController {
	
	@RequestMapping("/User.ds")
	public ModelAndView hello() {
		
		Map<String, String> userMap = new HashMap<>();
		userMap.put("Hello", "Hello");
		
		return new ModelAndView("Welcome",userMap);
	}
	
	@RequestMapping("/hi.ds")
	public ModelAndView hi() {
		
		Map<String, String> userMap = new HashMap<>();
		userMap.put("Hello", "Hi");
		
		return new ModelAndView("Welcome",userMap);
	}
}
