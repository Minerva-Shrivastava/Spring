package com.yash.app.controller;

import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.yash.app.model.User;

@Controller
@RequestMapping("/users")
public class UserController {
	
	@RequestMapping(value="/UserRegistration", method=RequestMethod.GET)
	public String showRegistrationForm() {
		System.out.println("/UserRegistration");
		return "UserRegistrationForm";
	}
	
	@RequestMapping(value="/ProcessUserRegistration", method=RequestMethod.POST)
	public ModelAndView processRegistrationForm(@RequestParam String name,@RequestParam String contact,@RequestParam String email,@RequestParam String password) 
	{
		System.out.println("ProcessRegistration");
		User user = new User();
		
		user.setName(name);
		user.setContact(contact);
		user.setEmail(email);
		user.setAddress(password);
		
		Map<String, User> userMap = new HashMap<>();
		userMap.put("user", user);
		return new ModelAndView("Welcome",userMap);
		
	}
}
