package com.yash.dams.domain;
/**
 * This class is used as a data traveller. this class will work as a model object.
 * Do not do any validations on this class
 * @author minerva.shrivastava
 *
 */
public class User {

	/**	id of User */
	private Integer id;
	
	/**	first_name of User */
	private String firstName;
	
	/**	last_name of User */
	private String lastName;
	
	/**	contact of User */
	private String contact;
	
	/**	email of User */
	private String email;
	
	/**	address of User */
	private String address;
	
	/**	loginName of User */
	private String loginName;
	
	/**	password of User */
	private String password;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	
	
}
