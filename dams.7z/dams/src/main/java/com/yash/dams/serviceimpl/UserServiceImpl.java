package com.yash.dams.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.dams.dao.UserDAO;
import com.yash.dams.domain.User;
import com.yash.dams.service.UserService;

/**
 * This class is the implementation of the Service interface 
 * providing service's implementation related to user 
 * @author minerva.shrivastava
 *
 */
@Service
public class UserServiceImpl implements UserService{

	/**
	 * The services call the DAO layer functionalities through this variable
	 */
	@Autowired
	private UserDAO userDAO;
	
	public int userRegistration(User user) {

		return userDAO.insert(user);
		
	}

	public User authenticateUser(String username, String password) {

		return userDAO.getUserByUsername_Password(username, password);
	}

	
}
