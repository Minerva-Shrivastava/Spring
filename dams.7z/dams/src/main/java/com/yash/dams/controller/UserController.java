package com.yash.dams.controller;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.yash.dams.domain.User;
import com.yash.dams.service.UserService;

/**
 * This controller will perform all the user related controlling
 * @author minerva.shrivastava
 *
 */
@Controller
@RequestMapping("/user")
@SessionAttributes("loggedInUser")
public class UserController {

	private static final Logger logger = Logger.getLogger(UserController.class);
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(value="/home.htm", method=RequestMethod.GET)
	  public String showHomePage(){
		return "home";
	  }
	
	@RequestMapping(value="/userRegistration.htm", method=RequestMethod.GET)
	  public String showUserRegistration(Model model){
		User user = new User();
		model.addAttribute(user);
		return "userRegistration";
	  }
	
	@RequestMapping(value="/processUserRegistration.htm", method=RequestMethod.POST)
	  public String processUserRegistration(@ModelAttribute("user") User user){
		userService.userRegistration(user);
		return "redirect:./home.htm";
	  }
	
	@RequestMapping(value="/userLogin.htm", method=RequestMethod.GET)
	  public String showLoginPage(){
		return "login";
	  }
	
	@RequestMapping(value="/userLogout.htm", method=RequestMethod.GET)
	  public String Logout(HttpSession httpSession){
		httpSession.invalidate();
		return "login";
	  }
	
	@RequestMapping(value="/processUserLogin.htm", method=RequestMethod.POST)
	  public String processUserLogin(@RequestParam String username , @RequestParam String password, Model model){
		User user = userService.authenticateUser(username,password);
		if(user != null)
			{
				model.addAttribute("loggedInUser",user);
			}
		
		return "forward:./dashboard.htm";
	  }
	
	@RequestMapping(value="/dashboard.htm", method=RequestMethod.POST)
	  public String showDashboardPage(){
		return "dashboard";
	  }
}
