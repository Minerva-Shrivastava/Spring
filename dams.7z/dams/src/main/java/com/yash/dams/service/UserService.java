package com.yash.dams.service;

import com.yash.dams.domain.User;

/**
 * This service will handle user related services
 * @author minerva.shrivastava
 *
 */
public interface UserService {

	/**
	 * This method registers the user
	 * @param user to register
	 * @return int 
	 */
	public int userRegistration(User user);

	public User authenticateUser(String username, String password);
	
}
