package com.yash.dams.dao;

import com.yash.dams.domain.User;

/**
 * This interface performs operations related with the user
 * @author minerva.shrivastava
 *
 */
public interface UserDAO {

	/**
	 * This method inserts the user into the database
	 * @param user
	 */
	public int insert(User user);

	public User getUserByUsername_Password(String username, String password);
	
}
