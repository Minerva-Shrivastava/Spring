package com.yash.dams.daoimpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.yash.dams.dao.UserDAO;
import com.yash.dams.domain.User;

/**
 * This class is the implementation of UserDAO
 * @author minerva.shrivastava
 *
 */
@Repository
public class UserDAOImpl implements UserDAO {
	
	/**
	 * jdbc Template for spring jdbc which takes datasource as parameter
	 */
	private JdbcTemplate jdbctemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbctemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * This method inserts the user into the database using jdbc.update() method 
	 * in which query and parameters are provided
	 */
	public int insert(User user) {

		String sql = "INSERT INTO damsdb.users(first_name,last_name,contact,email,address,loginName,password) VALUES(?,?,?,?,?,?,?)";
		Object[] params = new Object[] { 
				user.getFirstName(), 
				user.getLastName(), 
				user.getContact(), 
				user.getEmail(),
				user.getAddress(), 
				user.getLoginName(), 
				user.getPassword() };
		return jdbctemplate.update(sql, params);
		
	}

	public User getUserByUsername_Password(String username, String password) {

		String sql = "SELECT * FROM damsdb.users WHERE loginName=? and password=?";
		Object[] params = new Object[] {
				username,password
		};
		
		List<User> user = jdbctemplate.query(sql, params, new RowMapper<User>() {
			
		
			public User mapRow(ResultSet result, int arg1) throws SQLException {
				
				User user = new User();
				user.setId(Integer.parseInt(result.getString("id")));
				user.setFirstName(result.getString("first_name"));
				user.setLastName(result.getString("last_name"));
				user.setContact(result.getString("contact"));
				user.setEmail(result.getString("email"));
				user.setAddress(result.getString("address"));
				user.setLoginName(result.getString("loginName"));
				user.setPassword(result.getString("password"));
				return user;
				
			}});
		return user.get(0);
	}
	
}
